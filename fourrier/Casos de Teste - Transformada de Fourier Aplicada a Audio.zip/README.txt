Arquivo zip gerado em: 13/10/2019 22:30:02 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Transformada de Fourier Aplicada a Áudio