#include <stdlib.h>
#include <stdio.h>
#include <fourier.h>


int main(){
    char *file_name;
    int c,i,j;
    unsigned int **values;
    FILE *file;
    
    values = (unsigned int**)malloc(sizeof(unsigned int*)*c);
    
    scanf("%s",file_name);   
    file = fopen(file_name,"r");
    for(i=0;i<c;i++){
        values[i] = malloc(sizeof(unsigned int)*8);
        for(j=0;j<8;j++){
        fscanf(file,"%u",&values[i][j]);
        }


return 0;
    }    



}