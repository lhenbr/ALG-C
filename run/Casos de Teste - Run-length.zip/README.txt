Arquivo zip gerado em: 23/09/2019 11:43:59 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Run-length