Arquivo zip gerado em: 19/08/2019 15:41:01 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Transformada Discreta do Cosseno (DCT)